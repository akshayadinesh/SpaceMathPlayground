import SpriteKit
import PlaygroundSupport

public class GameScene: SKScene, SKPhysicsContactDelegate {

    public override func sceneDidLoad() {
        physicsWorld.contactDelegate = self
        self.startGame()
    }
    public func startGame() {
        hideGameOver()
        let asteroid1 = self.childNode(withName: "asteroid1") as! SKSpriteNode
        spawnAtTop(asteroid: asteroid1)
    }
    func moveAsteroidDown(asteroid: SKSpriteNode) {
        let moveAsteroidDownAction = SKAction.moveBy(x: 0.0,
                                               y: -628,
                                               duration: 4.0)
        asteroid.run(moveAsteroidDownAction, withKey: "moveDown")
    }
    
    func spawnAtTop(asteroid: SKSpriteNode) {
        let surprise = Int(arc4random_uniform(10))
        if surprise < 2 {
            asteroid.texture = SKTexture(imageNamed: "surprise")
        } else {
            asteroid.texture = SKTexture(imageNamed: "asteroid-icon")
        }
        let fadeIn = SKAction.fadeIn(withDuration: 0)
        asteroid.run(fadeIn)
        let Xpos = Int(arc4random_uniform(375)) - 187
        asteroid.position = CGPoint(x: Xpos, y: 370)
        let rotation = Int(arc4random_uniform(360))
        asteroid.zRotation = CGFloat(rotation)
        moveAsteroidDown(asteroid: asteroid)
    }

    public func didBegin(_ contact: SKPhysicsContact) {
        let contactA:SKPhysicsBody = contact.bodyA
        let contactB:SKPhysicsBody = contact.bodyB
        var asteroid: SKSpriteNode!
        if contactA.categoryBitMask == 4294967295 && contactB.categoryBitMask == 2 {
            asteroid = contactA.node as! SKSpriteNode
            asteroid.removeAction(forKey: "moveDown")
            asteroid.texture = SKTexture(imageNamed: "explosion")
            let fadeOut = SKAction.fadeOut(withDuration:1)
            asteroid.run(fadeOut) {
                self.endGame()
            }
        } else if contactB.categoryBitMask == 4294967295 && contactA.categoryBitMask == 2 {
            asteroid = contactB.node as! SKSpriteNode
            asteroid.removeAction(forKey: "moveDown")
            asteroid.texture = SKTexture(imageNamed: "explosion")
            let fadeOut = SKAction.fadeOut(withDuration:1)
            asteroid.run(fadeOut) {
                self.endGame()
            }
        }
        
    }
    
    public override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: self)
            let node : SKNode = self.atPoint(location)
            if node.name == "asteroid1" {
                showQueston(asteroid: node as! SKSpriteNode)
            }
            if node.name == "answerBox2" || node.name == "answer2" {
                endGame()
            }
            if node.name == "answerBox1" || node.name == "answer1" {
                self.hideQuestion()
                self.addToScore()
                let asteroid1 = self.childNode(withName: "asteroid1") as! SKSpriteNode
                self.spawnAtTop(asteroid: asteroid1)
            }
            if node.name == "playAgainBox" || node.name == "playAgainText" {
                self.startGame()
            }
        }
    }

    public func showQueston(asteroid: SKSpriteNode) {
        
        let questionLabel = self.childNode(withName: "question") as! SKLabelNode
        let answerBox1 = self.childNode(withName: "answerBox1") as! SKShapeNode
        let answerLabel1 = self.childNode(withName: "answer1") as! SKLabelNode
        let answerBox2 = self.childNode(withName: "answerBox2") as! SKShapeNode
        let answerLabel2 = self.childNode(withName: "answer2") as! SKLabelNode
        
        questionLabel.isHidden = false
        answerBox1.isHidden = false
        answerLabel1.isHidden = false
        answerBox2.isHidden = false
        answerLabel2.isHidden = false
        
        let results = generateQuestion()
        let questionText = results[0]
        let rightAnswer = results[1]
        let wrongAnswer = results[2]
        questionLabel.text = questionText
        answerLabel1.text = rightAnswer
        answerLabel2.text = wrongAnswer

        let random = Int(arc4random_uniform(2) + 1)
        if random == 1 {
            answerBox1.position = CGPoint(x: -64.8, y: -189)
            answerLabel1.position = CGPoint(x: -64.8, y: -189)
            answerBox2.position = CGPoint(x: 64.8, y: -189)
            answerLabel2.position = CGPoint(x: 64.8, y: -189)
        } else {
            answerBox1.position = CGPoint(x: 64.8, y: -189)
            answerLabel1.position = CGPoint(x: 64.8, y: -189)
            answerBox2.position = CGPoint(x: -64.8, y: -189)
            answerLabel2.position = CGPoint(x: -64.8, y: -189)
        }
        
    }
    
    public func generateQuestion() -> [String] {
        var firstNum = Int(arc4random_uniform(9) + 1)
        let secondNum = Int(arc4random_uniform(9) + 1)
        let operatorIndex = Int(arc4random_uniform(4))
        let operators = [" + ", " - ", " * ", " / "]
        let operation = operators[operatorIndex]
        
        var answer: Int = 0
        var wrongAnswer: Int = 0
        switch operation {
        case " + ":
            answer = firstNum + secondNum
            wrongAnswer = firstNum * secondNum
        case " - ":
            answer = firstNum - secondNum
            if firstNum != secondNum {
                wrongAnswer = secondNum - firstNum
            } else {
                wrongAnswer = firstNum + secondNum
            }
        case " * ":
            answer = firstNum * secondNum
            wrongAnswer = firstNum + secondNum
        case " / ":
            answer = firstNum
            firstNum = secondNum * answer
            wrongAnswer = firstNum * secondNum
        default:
            print("weird operation")
        }
        if(answer == wrongAnswer) {
            wrongAnswer = wrongAnswer + 1
        }
        
        let labelText = String(firstNum) + operation + String(secondNum) + " = "
        
        return [labelText, String(answer), String(wrongAnswer)]

    }
    
    public func endGame() {
        let scoreLabel = self.childNode(withName: "scoreLabel") as! SKLabelNode
        let blackSpace = self.childNode(withName: "black-space") as! SKSpriteNode
        let gameOver = self.childNode(withName: "gameOver") as! SKLabelNode
        let finalScore = self.childNode(withName: "finalScore") as! SKLabelNode
        let playAgainBox = self.childNode(withName: "playAgainBox") as! SKShapeNode
        let playAgainText = self.childNode(withName: "playAgainText") as! SKLabelNode
        let asteroid = self.childNode(withName: "asteroid1") as! SKSpriteNode
        asteroid.removeAllActions()
        
        finalScore.text = "Your \(scoreLabel.text!)"
        
        blackSpace.isHidden = false
        blackSpace.isPaused = false
        gameOver.isHidden = false
        gameOver.isPaused = false
        finalScore.isHidden = false
        finalScore.isPaused = false
        playAgainBox.isHidden = false
        playAgainBox.isPaused = false
        playAgainText.isHidden = false
        playAgainText.isPaused = false

        self.resetScore()
        self.hideQuestion()
    }
    
    public func resetScore() {
        let scoreLabel = self.childNode(withName: "scoreLabel") as! SKLabelNode
        scoreLabel.text = "Score: 0"
    }
    
    public func addToScore() {
        let scoreLabel = self.childNode(withName: "scoreLabel") as! SKLabelNode
        let text:String! = scoreLabel.text
        let i = text.index(text.startIndex, offsetBy: 7)
        let scoreNumber:String! = String(text[i...])
        var newScore:Int = Int(scoreNumber) as! Int
        newScore += 10
        scoreLabel.text = "Score: \(newScore)"
    }
    
    public func hideQuestion() {
        let questionLabel = self.childNode(withName: "question") as! SKLabelNode
        let answerBox1 = self.childNode(withName: "answerBox1") as! SKShapeNode
        let answerLabel1 = self.childNode(withName: "answer1") as! SKLabelNode
        let answerBox2 = self.childNode(withName: "answerBox2") as! SKShapeNode
        let answerLabel2 = self.childNode(withName: "answer2") as! SKLabelNode
        
        questionLabel.isHidden = true
        answerBox1.isHidden = true
        answerLabel1.isHidden = true
        answerBox2.isHidden = true
        answerLabel2.isHidden = true
        questionLabel.isPaused = true
        answerBox1.isPaused = true
        answerLabel1.isPaused = true
        answerBox2.isPaused = true
        answerLabel2.isPaused = true
    }
    
    public func hideGameOver() {
        let blackSpace = self.childNode(withName: "black-space") as! SKSpriteNode
        let gameOver = self.childNode(withName: "gameOver") as! SKLabelNode
        let finalScore = self.childNode(withName: "finalScore") as! SKLabelNode
        let playAgainBox = self.childNode(withName: "playAgainBox") as! SKShapeNode
        let playAgainText = self.childNode(withName: "playAgainText") as! SKLabelNode
        
        blackSpace.isHidden = true
        blackSpace.isPaused = true
        gameOver.isHidden = true
        gameOver.isPaused = true
        finalScore.isHidden = true
        finalScore.isPaused = true
        playAgainBox.isHidden = true
        playAgainBox.isPaused = true
        playAgainText.isHidden = true
        playAgainText.isPaused = true

    }
    
}


