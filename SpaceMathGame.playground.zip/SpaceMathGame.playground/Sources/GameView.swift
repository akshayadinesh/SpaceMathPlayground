import UIKit
import SpriteKit
import PlaygroundSupport

//This is the game's ViewController
public class GameViewController : UIViewController {
    
    //    let mainStackView = UIStackView()
    let controlPanelView = UIView()
    let problemView = UIStackView()
    let questionLabel = UILabel()
    let choicesSC = UISegmentedControl()
    let scoreLevelView = UIStackView()
    let levelLabel = UILabel()
    let scoreLabel = UILabel()
    let backButton = UINavigationItem()
    let infoButton = UINavigationItem()
    
    public override func loadView() {
        self.navigationController?.navigationBar.topItem?.title = ""
        self.navigationController?.setNavigationBarHidden(false, animated: false)
        let view = UIView()
        self.view = view
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Space Math Game"
        
        self.navigationItem.backBarButtonItem?.title = ""
        
        //        mainStackView.axis = .vertical
        //        mainStackView.distribution = .fillProportionally
        //        mainStackView.alignment = .center
        //        mainStackView.spacing = 20
        //        mainStackView.translatesAutoresizingMaskIntoConstraints = false
        //        view.addSubview(mainStackView)
        
        //Add constraints
        let sceneView = SKView(frame: CGRect(x: 0, y: 40, width: 375, height: 628))
        let scene = GameScene(fileNamed: "GameScene")
        // Set the scale mode to scale to fit the window
        scene?.scaleMode = .aspectFill
        
        // Present the scene
        sceneView.presentScene(scene)
        
//        controlPanelView.frame = CGRect(x: 0, y: height-400, width: width, height: 60)
        view.addSubview(sceneView)
//        view.addSubview(controlPanelView)
        
        //        view.addConstraints(
        //            NSLayoutConstraint.constraints(withVisualFormat: "H:|[gameView]|",
        //                                           options: NSLayoutFormatOptions(rawValue: 0),
        //                                           metrics: nil,
        //                                           views: ["gameView": gameView])
        //        )
        //        view.addConstraints(
        //            NSLayoutConstraint.constraints(withVisualFormat: "H:|[controlPanelView]|",
        //                                           options: NSLayoutFormatOptions(rawValue: 0),
        //                                           metrics: nil,
        //                                           views: ["controlPanelView": controlPanelView])
        //        )
        //        view.addConstraints(
        //            NSLayoutConstraint.constraints(withVisualFormat: "V:|[controlPanelView]-[gameView(60)]|",
        //                                           options: NSLayoutFormatOptions(rawValue: 0),
        //                                           metrics: nil,
        //                                           views: ["gameView": gameView, "controlPanelView": controlPanelView])
        //        )
        
        //Set up gameView
        //        gameView.frame = view.frame
        
        //Set up questionLabel
        questionLabel.text = "2 + 2 = "
        questionLabel.textColor = .white
        questionLabel.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        questionLabel.textAlignment = .right
        questionLabel.sizeToFit()
        
        //Set up choicesSC
        choicesSC.insertSegment(withTitle: "3", at: 0, animated: true)
        choicesSC.insertSegment(withTitle: "4", at: 1, animated: true)
        choicesSC.insertSegment(withTitle: "5", at: 2, animated: true)
        choicesSC.insertSegment(withTitle: "6", at: 3, animated: true)
        choicesSC.selectedSegmentIndex = 0
        choicesSC.contentHorizontalAlignment = .center
        
        //Set up problemView
        problemView.axis = .horizontal
        problemView.alignment = .center
        problemView.spacing = 10
        problemView.distribution = .fillProportionally
        problemView.translatesAutoresizingMaskIntoConstraints = false
        
        problemView.addArrangedSubview(questionLabel)
        problemView.addArrangedSubview(choicesSC)
        
        //Set up levelLabel
        levelLabel.text = "Level 2"
        levelLabel.textColor = .white
        levelLabel.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        levelLabel.textAlignment = .center
        levelLabel.sizeToFit()
        
        //Set up scoreLabel
        scoreLabel.text = "Score: 421"
        scoreLabel.textColor = .white
        scoreLabel.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        scoreLabel.textAlignment = .center
        scoreLabel.sizeToFit()
        
        //Set up scoreLevelView
        scoreLevelView.axis = .horizontal
        scoreLevelView.alignment = .center
        scoreLevelView.distribution = .fillProportionally
        scoreLevelView.spacing = 20
        scoreLevelView.sizeToFit()
        scoreLevelView.translatesAutoresizingMaskIntoConstraints = false
        
        scoreLevelView.addArrangedSubview(levelLabel)
        scoreLevelView.addArrangedSubview(scoreLabel)
        
        //Set up controlPanelStackView
        //        controlPanelStackView.axis = .vertical
        //        controlPanelStackView.distribution = .fillEqually
        //        controlPanelStackView.alignment = .center
        //        controlPanelStackView.spacing = 0
        //        controlPanelStackView.translatesAutoresizingMaskIntoConstraints = false
        //        controlPanelStackView.addArrangedSubview(problemView)
        //        controlPanelStackView.addArrangedSubview(scoreLevelView)
        
        controlPanelView.backgroundColor = .red
        controlPanelView.addSubview(problemView)
        controlPanelView.addSubview(scoreLevelView)
        
        controlPanelView.addConstraints(
            NSLayoutConstraint.constraints(withVisualFormat: "H:|[problemView]|",
                                           options: NSLayoutFormatOptions(rawValue: 0),
                                           metrics: nil,
                                           views: ["problemView": problemView])
        )
        controlPanelView.addConstraints(
            NSLayoutConstraint.constraints(withVisualFormat: "H:|[scoreLevelView]|",
                                           options: NSLayoutFormatOptions(rawValue: 0),
                                           metrics: nil,
                                           views: ["scoreLevelView": scoreLevelView])
        )
        controlPanelView.addConstraints(
            NSLayoutConstraint.constraints(withVisualFormat: "V:|[problemView][scoreLevelView]|",
                                           options: NSLayoutFormatOptions(rawValue: 0),
                                           metrics: nil,
                                           views: ["scoreLevelView": scoreLevelView, "problemView": problemView])
        )
        
    }
    public static func hello() {
        
    }
    
}

