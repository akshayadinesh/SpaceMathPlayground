import UIKit
import PlaygroundSupport

//This is the Main Menu ViewController
public class MainMenuViewController : UIViewController {
    
    let stackView = UIStackView()
    let titleLabel = UILabel()
    let descriptionLabel = UILabel()
    let letsGoButton = UIButton()
    let howToPlayButton = UIButton()
    let creditsButton = UIButton()
    let titleStackView = UIStackView()
    let buttonStackView = UIStackView()
    
    public override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        
        title = "Welcome to Space Math"
        
        //Set up stackView
        stackView.axis = .vertical
        stackView.alignment = .center
        stackView.spacing = 100
        stackView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(stackView)
        
        //Add constraints
        view.addConstraints(
            NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[stackView]-20-|",
                                           options: NSLayoutFormatOptions(rawValue: 0),
                                           metrics: nil,
                                           views: ["stackView": stackView])
        )
        view.addConstraints(
            NSLayoutConstraint.constraints(withVisualFormat: "V:|-60-[stackView]-60-|",
                                           options: NSLayoutFormatOptions(rawValue: 0),
                                           metrics: nil,
                                           views: ["stackView": stackView])
        )
        
        //Set up titleLabel
        titleLabel.text = "Space Math"
        titleLabel.textAlignment = .center
        titleLabel.textColor = UIColor.white
        titleLabel.font = UIFont(name: "HelveticaNeue-MediumItalic", size: 30.0)
        titleLabel.sizeToFit()
        
        //Set up descriptionLabel
        descriptionLabel.text = "An educational math Swift Playground created by yours truly, Akshaya Dinesh."
        descriptionLabel.textColor = UIColor.white
        descriptionLabel.textAlignment = .center
        descriptionLabel.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        descriptionLabel.numberOfLines = 3
        descriptionLabel.sizeToFit()
        stackView.setCustomSpacing(20, after: descriptionLabel)
        
        //Set up letsGoButton
        letsGoButton.backgroundColor = .black
        letsGoButton.layer.cornerRadius = 5
        letsGoButton.layer.borderColor = UIColor.white.cgColor
        letsGoButton.layer.borderWidth = 2
        letsGoButton.setTitle("Let's Go!", for: .normal)
        letsGoButton.titleLabel?.font = UIFont(name: "HelveticaNeue", size: 20.0)
        letsGoButton.setTitleColor(.white, for: .normal)
        letsGoButton.titleLabel?.shadowOffset = CGSize(width: 1, height: 1)
        letsGoButton.setTitleShadowColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .highlighted)
        letsGoButton.contentEdgeInsets = UIEdgeInsetsMake(10,15,10,15)
        letsGoButton.addTarget(self, action: #selector(MainMenuViewController.letsGo), for: .touchUpInside)
        
        //Set up howToPlayButton
        howToPlayButton.backgroundColor = .black
        howToPlayButton.layer.cornerRadius = 5
        howToPlayButton.layer.borderColor = UIColor.white.cgColor
        howToPlayButton.layer.borderWidth = 2
        howToPlayButton.setTitle("How to Play", for: .normal)
        howToPlayButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        howToPlayButton.setTitleColor(.white, for: .normal)
        howToPlayButton.titleLabel?.shadowOffset = CGSize(width: 0.5, height: 0.5)
        howToPlayButton.setTitleShadowColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .highlighted)
        howToPlayButton.contentEdgeInsets = UIEdgeInsetsMake(10,15,10,15)
        howToPlayButton.addTarget(self, action: #selector(MainMenuViewController.howToPlay), for: .touchUpInside)
        
        
        //Set up creditsButton
        creditsButton.backgroundColor = .black
        creditsButton.layer.cornerRadius = 5
        creditsButton.layer.borderColor = UIColor.white.cgColor
        creditsButton.layer.borderWidth = 2
        creditsButton.setTitle("Credits", for: .normal)
        creditsButton.titleLabel?.font = UIFont(name: "HelveticaNeue-Thin", size: 20.0)
        creditsButton.setTitleColor(.white, for: .normal)
        creditsButton.titleLabel?.shadowOffset = CGSize(width: 0.5, height: 0.5)
        creditsButton.setTitleShadowColor(#colorLiteral(red: 1, green: 1, blue: 1, alpha: 1), for: .highlighted)
        creditsButton.contentEdgeInsets = UIEdgeInsetsMake(10,15,10,15)
        creditsButton.addTarget(self, action: #selector(MainMenuViewController.showCredits), for: .touchUpInside)
        
        titleStackView.axis = .vertical
        titleStackView.spacing = 20
        titleStackView.addArrangedSubview(titleLabel)
        titleStackView.addArrangedSubview(descriptionLabel)
        
        buttonStackView.axis = .vertical
        buttonStackView.spacing = 20
        buttonStackView.addArrangedSubview(letsGoButton)
        buttonStackView.addArrangedSubview(howToPlayButton)
        buttonStackView.addArrangedSubview(creditsButton)
        
        //Add all subviews to stack
        stackView.addArrangedSubview(titleStackView)
        stackView.addArrangedSubview(buttonStackView)
        
        view.backgroundColor = UIColor(patternImage: UIImage(named: "space.png")!)
        
    }
    
    
    public override func loadView() {
        self.navigationController?.setNavigationBarHidden(true, animated: false)
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 512, height: 384))
        self.view = view
        super.loadView()
    }
    
    @IBAction func letsGo() {
        self.navigationController?.pushViewController(GameViewController(), animated: true)
        //        PlaygroundPage.current.liveView = GameViewController()
    }
    
    @IBAction func howToPlay() {
        let alertController = UIAlertController(title: "How to Play", message: "1. Asteroids are flying towards Earth.\n2. Click on them before they fall to the surface.\n3. Solve the math problem to make them disappear.\n4. Repeat to stay alive!\n💥🚀🌎☄️", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        present(alertController, animated: true, completion: nil)
        //        var buttonclick = true
    }
    
    @IBAction func showCredits() {
        let alertController = UIAlertController(title: "App Credits", message: "Created by: Akshaya Dinesh\nApplication for WWDC 2018🌎\n\nNote: This was my first time using Swift and it was so much fun!💻\nCan't wait to learn more during WWDC😊", preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        present(alertController, animated: true, completion: nil)
        //        var buttonclick = true
    }
}



