//: 

import UIKit
import SpriteKit
import PlaygroundSupport

// Present the view controller in the Live View window
let navigationController = UINavigationController(rootViewController: MainMenuViewController())
navigationController.addChildViewController(MainMenuViewController())
PlaygroundPage.current.liveView = navigationController
